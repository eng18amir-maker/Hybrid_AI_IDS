import time
import requests
import random

API_URL = "http://localhost:8000/api/alerts"

def generate_attack_traffic(attack_type):
    if attack_type == "Botnet":
        return {
            "dest_port": 4444,
            "Destination Port": 4444,
            "source": "zeek",
            # القديم
            "Bwd Packet Length Max": 1460.0,
            "Flow Iat Max": 60000.0,
            "Init_Win_Bytes_Forward": 29200.0,
            "Packet Length Max": 1460.0,
            "Init_Win_Bytes_Backward": 28960.0,
            "Packet Length Mean": 450.0,
            "Fwd Packet Length Max": 1000.0,
            "Flow Packets/s": 3500.0,
            "Avg Bwd Segment Size": 350.0,
            "Bwd Packet Length Mean": 350.0,
            "Packet Length Std": 150.0,
            "Flow Bytes/s": 800000.0,
            "Bwd Packets/s": 1500.0,
            "Fwd Packet Length Mean": 500.0,
            "Avg Fwd Segment Size": 500.0,
            "Flow Duration": 200000,
            "Fwd Iat Max": 50000.0,
            # الجديد المضاف
            "Flow IAT Mean": 2000.0,
            "Flow IAT Std": 500.0,
            "Flow IAT Max": 60000.0,
            "Bwd IAT Mean": 1200.0,
            "Bwd IAT Max": 5000.0,
            "Bwd IAT Min": 50.0,
            "Fwd IAT Mean": 1500.0,
            "Fwd IAT Std": 400.0,
            "Packet Length Min": 0.0,
            "Packet Length Variance": 25000.0,
            "Init Fwd Win Bytes": 29200,
            "Init Bwd Win Byte": 28960
        }
    elif attack_type == "Brute_Force":
        return {
            "dest_port": 22,
            "Destination Port": 22,
            "source": "zeek",
            # القديم
            "Bwd Packet Length Max": 0.0,
            "Flow Iat Max": 15000.0,
            "Init_Win_Bytes_Forward": 65535.0,
            "Packet Length Max": 64.0,
            "Init_Win_Bytes_Backward": 0.0,
            "Packet Length Mean": 48.0,
            "Fwd Packet Length Max": 64.0,
            "Flow Packets/s": 8000.0,
            "Avg Bwd Segment Size": 0.0,
            "Bwd Packet Length Mean": 0.0,
            "Packet Length Std": 12.0,
            "Flow Bytes/s": 400000.0,
            "Bwd Packets/s": 0.0,
            "Fwd Packet Length Mean": 48.0,
            "Avg Fwd Segment Size": 48.0,
            "Flow Duration": 50000,
            "Fwd Iat Max": 12000.0,
            # الجديد المضاف
            "Flow IAT Mean": 50.0,
            "Flow IAT Std": 10.0,
            "Flow IAT Max": 15000.0,
            "Bwd IAT Mean": 0.0,
            "Bwd IAT Max": 0.0,
            "Bwd IAT Min": 0.0,
            "Fwd IAT Mean": 45.0,
            "Fwd IAT Std": 8.0,
            "Packet Length Min": 40.0,
            "Packet Length Variance": 150.0,
            "Init Fwd Win Bytes": 65535,
            "Init Bwd Win Byte": 0
        }
    else:
        chosen_port = random.choice([80, 443, 53])
        return {
            "dest_port": chosen_port,
            "Destination Port": chosen_port,
            "source": random.choice(["zeek", "suricata"]),
            # القديم
            "Bwd Packet Length Max": random.uniform(0, 100),
            "Flow Iat Max": random.uniform(10, 5000),
            "Init_Win_Bytes_Forward": random.uniform(200, 4000),
            "Packet Length Max": random.uniform(40, 120),
            "Init_Win_Bytes_Backward": random.uniform(200, 4000),
            "Packet Length Mean": random.uniform(40, 80),
            "Fwd Packet Length Max": random.uniform(40, 100),
            "Flow Packets/s": random.uniform(10, 100),
            "Avg Bwd Segment Size": random.uniform(10, 50),
            "Bwd Packet Length Mean": random.uniform(10, 50),
            "Packet Length Std": random.uniform(0, 20),
            "Flow Bytes/s": random.uniform(1000, 5000),
            "Bwd Packets/s": random.uniform(5, 50),
            "Fwd Packet Length Mean": random.uniform(40, 80),
            "Avg Fwd Segment Size": random.uniform(40, 80),
            "Flow Duration": random.randint(1000, 20000),
            "Fwd Iat Max": random.uniform(10, 5000),
            # الجديد المضاف
            "Flow IAT Mean": random.uniform(100, 3000),
            "Flow IAT Std": random.uniform(10, 500),
            "Flow IAT Max": random.uniform(500, 6000),
            "Bwd IAT Mean": random.uniform(10, 2000),
            "Bwd IAT Max": random.uniform(50, 5000),
            "Bwd IAT Min": random.uniform(0, 10),
            "Fwd IAT Mean": random.uniform(50, 2000),
            "Fwd IAT Std": random.uniform(10, 500),
            "Packet Length Min": random.uniform(0, 40),
            "Packet Length Variance": random.uniform(50, 2000),
            "Init Fwd Win Bytes": random.randint(1000, 4000),
            "Init Bwd Win Byte": random.randint(1000, 4000)
        }

def start_injector():
    attack_types = ["Botnet", "Brute_Force", "Benign"]
    print("[*] Unified Ingestion Active (All Features Combined)...")
    while True:
        chosen = random.choice(attack_types)
        payload = generate_attack_traffic(chosen)
        try:
            response = requests.post(API_URL, json=payload, timeout=2)
            print(f"[+] Injected: {chosen} | Server Code: {response.status_code}")
        except requests.exceptions.RequestException:
            print(f"[-] Failed to inject: {chosen}")
        time.sleep(2)

if __name__ == "__main__":
    start_injector()
