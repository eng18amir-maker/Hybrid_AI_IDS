from fastapi import FastAPI
app = FastAPI(title="Hybrid AI IDS Dashboard")
@app.get("/api/alerts")
def get_alerts():
    return [
        {"id": 1, "timestamp": "2026-06-14T17:05:00", "source_ip": "192.168.1.50", "destination_ip": "10.0.0.5", "signature": "Potential SQL Injection Attempt", "severity": "High"},
        {"id": 2, "timestamp": "2026-06-14T17:05:30", "source_ip": "192.168.1.99", "destination_ip": "10.0.0.5", "signature": "DDOS Attack Detected - Syn Flood", "severity": "Critical"},
        {"id": 3, "timestamp": "2026-06-14T17:06:12", "source_ip": "185.220.101.5", "destination_ip": "10.0.0.12", "signature": "Brute Force Attempt on SSH Port 22", "severity": "Medium"}
    ]
