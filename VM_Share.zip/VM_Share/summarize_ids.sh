#!/bin/bash

# Elasticsearch host
ES_HOST="http://localhost:9200"

# Indices
INDICES=("zeek-2026.01.26" "suricata-2026.01.26")

echo "==================== IDS SUMMARY ===================="

for INDEX in "${INDICES[@]}"; do
    echo ""
    echo "Index: $INDEX"

    # Total docs
    TOTAL=$(curl -s "$ES_HOST/$INDEX/_count" | jq '.count')
    echo "Total events: $TOTAL"

    # Top 10 source IPs
    echo "Top 10 source IPs:"
    curl -s "$ES_HOST/$INDEX/_search?size=0" -H 'Content-Type: application/json' -d"
    {
      \"aggs\": {
        \"top_src_ips\": {
          \"terms\": { \"field\": \"src_ip.keyword\", \"size\": 10 }
        }
      }
    }" | jq '.aggregations.top_src_ips.buckets[] | "\(.key) => \(.doc_count)"'

    # Top 10 destination IPs
    echo "Top 10 destination IPs:"
    curl -s "$ES_HOST/$INDEX/_search?size=0" -H 'Content-Type: application/json' -d"
    {
      \"aggs\": {
        \"top_dest_ips\": {
          \"terms\": { \"field\": \"dest_ip.keyword\", \"size\": 10 }
        }
      }
    }" | jq '.aggregations.top_dest_ips.buckets[] | "\(.key) => \(.doc_count)"'

    # Top 5 protocols
    echo "Top 5 protocols:"
    curl -s "$ES_HOST/$INDEX/_search?size=0" -H 'Content-Type: application/json' -d"
    {
      \"aggs\": {
        \"top_proto\": {
          \"terms\": { \"field\": \"proto.keyword\", \"size\": 5 }
        }
      }
    }" | jq '.aggregations.top_proto.buckets[] | "\(.key) => \(.doc_count)"'

    # For Suricata: flagged alerts
    if [[ "$INDEX" == suricata* ]]; then
        echo "Suricata alerts:"
        curl -s "$ES_HOST/$INDEX/_search?size=0" -H 'Content-Type: application/json' -d"
        {
          \"query\": { \"term\": { \"event.alerted\": true } }
        }" | jq '.hits.total.value'
    fi
done

echo "===================================================="
