let lineChart, donutChart;

async function loadChartsFromAPI() {
    try {
   
       const res = await fetch("http://127.0.0.1:9001/dashboard-stats");
        if (!res.ok) throw new Error("Chart fetch failed");
        
        const data = await res.json();

       
        const ctxLine = document.getElementById('lineChart');
        if (ctxLine) {
            const context = ctxLine.getContext('2d');
            if (lineChart) lineChart.destroy(); 

           
            const trendData = [
                Math.max(0, data.total_requests - 5),
                Math.max(0, data.total_requests - 3),
                Math.max(0, data.total_requests - 1),
                data.total_requests
            ];

            lineChart = new Chart(context, {
                type: 'line',
                data: {
                    labels: ['T-3', 'T-2', 'T-1', 'Now'],
                    datasets: [{
                        label: 'Total Traffic',
                        data: trendData,
                        borderColor: '#3b82f6',
                        tension: 0.4, // لجعل الخط منحني وشكله أشيك
                        fill: true,
                        backgroundColor: 'rgba(59, 130, 246, 0.1)'
                    }]
                },
                options: { responsive: true, maintainAspectRatio: false }
            });
        }

       
        const ctxDonut = document.getElementById('donutChart');
        if (ctxDonut) {
            const context = ctxDonut.getContext('2d');
            if (donutChart) donutChart.destroy();

            
           const labels = Object.keys(data.attackTypes);
const values = Object.values(data.attackTypes);

            donutChart = new Chart(context, {
                type: 'doughnut',
                data: {
                    labels: labels,
                    datasets: [{
                        data: values,
                        backgroundColor: ['#10b981', '#f87171', '#3b82f6', '#fbbf24', '#8b5cf6'],
                        hoverOffset: 4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { position: 'bottom' }
                    }
                }
            });
        }

    } catch (err) {
        console.error("Charts Error:", err);
    }
}


loadChartsFromAPI();