const defaultSettings = {
    threshold: 50,
    model: "CNN"
};

function loadSettings(){
    const s = JSON.parse(localStorage.getItem("settings")) || defaultSettings;

    document.getElementById("threshold").value = s.threshold;
    document.getElementById("thresholdValue").textContent = s.threshold;
    document.getElementById("modelSelect").value = s.model;
}

document.getElementById("threshold").addEventListener("input",(e)=>{
    document.getElementById("thresholdValue").textContent = e.target.value;
});

document.getElementById("saveSettings").addEventListener("click",()=>{
    const settings = {
        threshold: document.getElementById("threshold").value,
        model: document.getElementById("modelSelect").value
    };

    localStorage.setItem("settings", JSON.stringify(settings));
    alert("Saved");
});

document.getElementById("resetSettings").addEventListener("click",()=>{
    localStorage.removeItem("settings");
    loadSettings();
});

loadSettings();

