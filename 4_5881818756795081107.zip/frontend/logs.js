
console.log("LOGS FILE LOADED");

async function loadLogs() {

    try {

        const res = await fetch("http://127.0.0.1:9001/logs");

        const logs = await res.json();

        console.log("Logs Data:", logs);

        renderLogs(logs);

        renderLogsCharts(logs);

    } catch (err) {

        console.error("Logs Error:", err);
    }
}

function renderLogs(logs) {

    const tbody = document.getElementById("logsBody");

    if (!tbody) return;

    tbody.innerHTML = "";

    logs.forEach(log => {

       tbody.innerHTML += `
<tr>
    <td>${log.timestamp}</td>
    <td>${log.sourceIP}</td>
    <td>${log.destIP}</td>
    <td>TCP</td>
    <td>${Math.floor(Math.random() * 1000) + 100}</td>
    <td>${Math.floor(Math.random() * 800) + 100}</td>
    <td>${log.status}</td>
</tr>
`;
        ;

    });
}

function renderLogsCharts(logs) {

    const donutCanvas = document.getElementById("trafficDonut");

    if (donutCanvas) {

        const blocked = logs.filter(
            log => log.status === "Blocked"
        ).length;

        const allowed = logs.filter(
            log => log.status === "Allowed"
        ).length;

        new Chart(donutCanvas, {
            type: "doughnut",
            data: {
                labels: ["Blocked", "Allowed"],
                datasets: [{
                    data: [blocked, allowed],
                    backgroundColor: [
                        "#ef4444",
                        "#10b981"
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
    }

    const barCanvas = document.getElementById("trafficBar");

    if (barCanvas) {

        new Chart(barCanvas, {
            type: "bar",
            data: {
                labels: ["TCP", "UDP", "HTTP", "HTTPS"],
                datasets: [{
                    label: "Traffic",
                    data: [500, 300, 250, 200],
                    backgroundColor: "#3b82f6"
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
    }
}

document.addEventListener("DOMContentLoaded", loadLogs);

