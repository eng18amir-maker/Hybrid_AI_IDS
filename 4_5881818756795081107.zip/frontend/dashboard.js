
let dashboardData = {
    totalRequests: 0,
    detectedAttacks: 0,
    networkAttacks: 0,
    chartLabels: [],
    chartData: [],
    attackTypes: {
        benign: 0,
        ddos: 0,
        bot: 0
    }
};


async function loadDashboardData() {
    try {

        const res = await fetch("http://127.0.0.1:9001/dashboard-stats");
        const data = await res.json();

        console.log("Dashboard Data:", data);

        dashboardData = {
            totalRequests: data.totalRequests || 0,
            detectedAttacks: data.detectedAttacks || 0,
            networkAttacks: data.networkAttacks || 0,

            chartLabels: data.chartLabels || [],
            chartData: data.chartData || [],

          attackTypes: {
    benign: data.attackTypes?.benign || 0,
    ddos: data.attackTypes?.ddos || 0,
    bot: data.attackTypes?.bot || 0
}
        };

    } catch (err) {

        console.log("Backend not connected → using demo data");

        dashboardData = {
            totalRequests: 1500,
            detectedAttacks: 320,
            networkAttacks: 210,

            chartLabels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
            chartData: [120, 150, 130, 170, 140, 160],

            attackTypes: {
                benign: 50,
                ddos: 30,
                bot: 20
            }
        };
    }

   updateDashboardUI();
    renderCharts();
}


function updateDashboardUI() {
       
    console.log("Updating UI:", dashboardData);
    const totalReq = document.getElementById('total-req');
    const attacksDetected = document.getElementById('attacks-detected');
    const networkAttacks = document.getElementById('network-attacks');

    if (totalReq) {
    totalReq.textContent = dashboardData.totalRequests;
}

if (attacksDetected) {
    attacksDetected.textContent = dashboardData.detectedAttacks;
}

if (networkAttacks) {
    networkAttacks.textContent = dashboardData.networkAttacks;
}

    const benignCount = document.getElementById('benign-count');
    const ddosCount = document.getElementById('ddos-count');
    const botCount = document.getElementById('bot-count');

    if (benignCount)
        benignCount.textContent = dashboardData.attackTypes.benign;

    if (ddosCount)
        ddosCount.textContent = dashboardData.attackTypes.ddos;

    if (botCount)
        botCount.textContent = dashboardData.attackTypes.bot;
}


let lineChart;
let donutChart;

function renderCharts() {

    const ctxLine = document.getElementById('lineChart')?.getContext('2d');

    if (ctxLine) {

        if (lineChart)
            lineChart.destroy();

        lineChart = new Chart(ctxLine, {
            type: 'line',
            data: {
                labels: dashboardData.chartLabels,
                datasets: [{
                    label: 'Network Attacks',
                    data: dashboardData.chartData,
                    borderColor: '#3b82f6',
                    backgroundColor: 'rgba(59,130,246,0.2)',
                    tension: 0.3,
                    pointRadius: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true
            }
        });
    }

    const ctxDonut = document.getElementById('donutChart')?.getContext('2d');

    if (ctxDonut) {

        if (donutChart)
            donutChart.destroy();

        donutChart = new Chart(ctxDonut, {
            type: 'doughnut',
            data: {
                labels: ['Benign', 'DDoS', 'Bot'],
                datasets: [{
                    data: [
                        dashboardData.attackTypes.benign,
                        dashboardData.attackTypes.ddos,
                        dashboardData.attackTypes.bot
                    ],
                    backgroundColor: [
                        '#3b82f6',
                        '#2563eb',
                        '#10b981'
                    ]
                }]
            },
            options: {
                responsive: true
            }
        });
    }
}


setInterval(loadDashboardData, 10000);


document.addEventListener("DOMContentLoaded", loadDashboardData);




