console.log("ALERTS FILE LOADED");

async function loadAlerts() {

    try {

        const res = await fetch("http://127.0.0.1:9001/alerts");

        const data = await res.json();

        console.log("Alerts API Response:", data);

        renderAlerts(data);

    } catch (err) {

        console.error("Alerts Error:", err);
    }
}

function renderAlerts(alerts) {

    console.log("renderAlerts works");
    console.log("Alerts Received:", alerts);

    const tbody = document.getElementById("alertsBody");

    if (!tbody) return;

    tbody.innerHTML = "";

    alerts.forEach(a => {

        tbody.innerHTML += `
        <tr>
            <td>${a.timestamp}</td>
            <td>${a.type}</td>
            <td>${a.sourceIP}</td>
            <td>${a.destIP}</td>

            <td class="severity-${a.severity.toLowerCase()}">
                ${a.severity}
            </td>

            <td>${a.model}</td>

            <td>${a.status}</td>

            <td>
                <button class="view-details">
                    View Details
                </button>
             
                <button class="mark-resolved">
                    Resolve
                </button>
            </td>
        </tr>
        `;
    });
}

document.addEventListener("DOMContentLoaded", loadAlerts);





 


document.addEventListener("click", function (e) {

   


    if (e.target.classList.contains("view-details")) {
        const row = e.target.closest("tr");

        const alertData = {
            timestamp: row.children[0].innerText,
            type: row.children[1].innerText,
            sourceIP: row.children[2].innerText,
            destIP: row.children[3].innerText,
            severity: row.children[4].innerText,
            model: row.children[5].innerText,
            status: row.children[6].innerText,
        };

        console.log("VIEW CLICKED:", alertData);

        alert("View clicked for: " + alertData.type);
    }

   


   if (e.target.classList.contains("mark-resolved")) {

    const row = e.target.closest("tr");

    
    const statusCell = row.children[6];

    statusCell.innerText = "Resolved";
    statusCell.style.color = "limegreen";
    statusCell.style.fontWeight = "bold";

  
    e.target.innerText = "Resolved";
    e.target.disabled = true;
    e.target.style.opacity = "0.6";
    e.target.style.cursor = "not-allowed";

    console.log("RESOLVE DONE");
}
});







