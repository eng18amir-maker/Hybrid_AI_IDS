async function loadUsers() {
    const res = await fetch("http://127.0.0.1:9001/users");
    const data = await res.json();
    renderUsers(data);
}

function renderUsers(users) {
    const tbody = document.getElementById("usersBody");
    if (!tbody) return;

    tbody.innerHTML = "";

    users.forEach(u => {
        tbody.innerHTML += `
        <tr>
            <td>${u.username}</td>
            <td>${u.role}</td>
            <td>${u.status}</td>
        </tr>`;
    });
}

document.addEventListener("DOMContentLoaded", loadUsers);