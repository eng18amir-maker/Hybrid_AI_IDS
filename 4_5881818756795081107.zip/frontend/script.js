const API_BASE = "http://127.0.0.1:9001";

const loginBtn = document.getElementById("loginBtn");
const errorMsg = document.getElementById("errorMsg");

loginBtn.addEventListener("click", async () => {
    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value.trim();

    if (!username || !password) {
        errorMsg.style.display = "block";
        errorMsg.textContent = "Please enter username and password.";
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/login`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ username, password })
        });

        let data = {};

        try {
            data = await response.json();
        } catch {
            data = {};
        }

        if (!response.ok) {
            errorMsg.style.display = "block";
            errorMsg.textContent = data.detail || "Login failed";
            return;
        }

        if (data.role) {
            window.location.href = `dashboard.html?role=${data.role}`;
        } else {
            errorMsg.style.display = "block";
            errorMsg.textContent = "Invalid credentials";
        }

    } catch (error) {
        console.error("ERROR:", error);
        errorMsg.style.display = "block";
        errorMsg.textContent = "Backend not reachable (check server)";
    }
});