const navItems = document.querySelectorAll('.nav-item');
const pages = document.querySelectorAll('.page');

navItems.forEach(item => {
    item.addEventListener('click', () => {

        navItems.forEach(i => i.classList.remove('active'));
        item.classList.add('active');

        pages.forEach(p => p.style.display = 'none');

        const page = document.querySelector(`.${item.dataset.page}-page`);
        if(page) page.style.display = 'block';

        document.getElementById('page-title').textContent = item.textContent;
    });
});