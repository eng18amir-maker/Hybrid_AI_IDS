async function loadModels() {
    try {
       const res = await fetch("http://127.0.0.1:9001/models");
        const data = await res.json();

        renderModels(data);
    } catch (err) {
        console.error("Models Error:", err);
    }
}

function renderModels(models) {
    const container = document.querySelector(".models-container");
    container.innerHTML = "";

    models.forEach(model => {
        const card = document.createElement("div");

        card.classList.add("model-card");

        card.innerHTML = `
            <h3>${model.name}</h3>
            <p>Type: ${model.type}</p>
            <p>Dataset: ${model.dataset}</p>
            <p>Accuracy: ${model.accuracy || "N/A"}</p>
        `;

        container.appendChild(card);
    });
}

loadModels();